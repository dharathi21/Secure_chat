from flask import Flask,render_template,request,redirect,url_for
from flask_socketio import SocketIO,join_room
app=Flask(__name__)
socketio=SocketIO(app,async_mode='eventlet')

@app.route('/')
def home():
    return render_template("home.html")

@socketio.on('public_key')
def handle_public_key(data):
    socketio.emit('receive_public_key',data,room=data['room'])

@socketio.on('aes_key')
def handle_aes_key(data):
     socketio.emit('receive_aes_key', data,room=data['room'])


@socketio.on('room_join')
def handle_room_join(data):
    app.logger.info("{} is joined to the chat room {}".format(data['username'],data['room']))
    join_room(data['room'])
    socketio.emit('room_announcement',data)

@socketio.on('send_message')
def handle_send_message(data):
    app.logger.info("{} is send a message to  chat room {} that {}".format(data['username'], data['room'],data['message']))
    socketio.emit('receive_message',data,room=data['room'])


@app.route('/chat')
def chat():
    username=request.args.get('username')
    room =request.args.get('room')

    if username and room:
        return render_template("chat.html",username=username,room=room)
    else:
        return redirect(url_for('home'))



if __name__=='__main__':
    socketio.run(app,debug=True)
